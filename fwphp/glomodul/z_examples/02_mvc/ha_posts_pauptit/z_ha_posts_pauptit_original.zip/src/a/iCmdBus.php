<?php
interface iCmdBus
{
    public function execute(iCmd $command);
}
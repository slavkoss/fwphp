<?php
interface iCmdHndl
{
    public function handle(CommandInterface $command);
}
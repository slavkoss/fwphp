<?php
//namespace App\Post\Application\Cmd;

//use App\Common\Contracts\Cmd\Post\iCmd;

class CrePostCmd implements iCmd
{
    private $title;
    private $contents;

    public function __construct($title, $contents)
    {
        $this->title = $title;
        $this->contents = $contents;
    }

    public function getTitle()
    {
        return $this->title;
    }

    public function getContents()
    {
        return $this->contents;
    }
}
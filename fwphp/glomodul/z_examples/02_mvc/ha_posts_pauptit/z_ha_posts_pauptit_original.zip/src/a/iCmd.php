<?php
interface iCmd {}
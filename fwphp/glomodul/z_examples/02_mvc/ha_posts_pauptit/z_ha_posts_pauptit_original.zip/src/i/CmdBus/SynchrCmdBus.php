<?php
class SynchrCmdBus implements iCmdBus
{
  /** @var CommandHandlerInterface[] */
  private $handlers = [];

  public function execute(iCmd $command)
  {
    $commandName = get_class($command);

    // Check if Command that's given is actually registered to be handled here.
    if (!array_key_exists($commandName, $this->handlers) {
        throw new Exception("{$commandName} is not supported by the SynchronousCommandBus.");
    }

    return $this->handlers[$commandName]->handle($command);
  }

  // Now all we need is a function to register handlers
  public function register($commandName, iCmdHndl $command)
  {
    $this->handlers[$commandName] = $handler;
    return $this;
  }
}

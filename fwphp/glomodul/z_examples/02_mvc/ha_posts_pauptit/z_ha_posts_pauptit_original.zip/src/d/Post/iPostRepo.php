<?php
interface iPostRepo
{
    public function create(Post $post);
}
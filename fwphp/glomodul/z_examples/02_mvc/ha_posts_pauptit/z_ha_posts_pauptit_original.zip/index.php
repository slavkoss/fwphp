<?php
//J:\awww\www\fwphp\glomodul\z_examples\02_mvc\ha_posts_pauptit\index.php  or test.php

$cmdBus = new SynchrCmdBus();

$postRepo = new PostRepo;
$cmdHndl  = new CreUserHndl($postRepo);

$cmdBus->register(CrePostCmd::class, $cmdHndl);

$cmd = new CrePostCmd(
    "This is the post title", 
    "And this is the content"
);

$cmdBus->execute($cmd);
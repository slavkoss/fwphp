<?php

namespace App\Infrastructure;

use App\Domain\z_GalleryDataFinderInterface;

class z_GalleryRepository implements z_GalleryDataFinderInterface
{
    /** @var GalleryDriverInterface */
    private $driver;

    /**
     * GalleryRepository constructor.
     *
     * @param GalleryDriverInterface $driver
     */
    public function __construct(GalleryDriverInterface $driver)
    {
        $this->driver = $driver;
    }

    /**
     * @param array $options
     *
     * @return array
     */
    public function findAll (array $options): array
    {
        return $this->driver->findAll($options);
    }
}

<?php

namespace App\Controller;

use App\Config\Config;
use App\Config\Message\Response;
//use Twig\Environment as TwigEnvironment;
//use Twig\Loader\FilesystemLoader as TwigFilesystemLoader;
use Exception;

trait ControllerTrait
{
    /** @var Config */
    private $config;
    /**
     * @param string $param
     *
     * @return mixed
     *
     * @throws Exception
     */
    private function getParameter(string $param)
    {
        return $this->config->getParameter($param);
    }

    /**
     * @param string $template
     * @param array $params
     *
     * @return Response
     */
    private function render(string $template, array $params): Response
    {
                       echo '<pre>ctrtrait 1. $params='; print_r($params) ; echo '</pre>'; 
        try {
            //return new R esponse($this->getTemplate()->r ender($template, $params));
            return new Response(__METHOD__ .' SAYS : aaaaaaaaa');
        } catch (Exception $exception) {
            $this->logger->error('Error: ' . $exception->getMessage());
        }
    }

    /**
     * @return TwigEnvironment
     */
    private function getTemplate()
    {
        try {
            $loader = new TwigFilesystemLoader($this->getParameter('TEMPLATE_PATH'));
            return new TwigEnvironment($loader, [
                'cache' => $this->getParameter('CACHE_PATH'),
            ]);
        } catch (Exception $exception) {
            $this->logger->error('Error: ' . $exception->getMessage());
        }
    }
}

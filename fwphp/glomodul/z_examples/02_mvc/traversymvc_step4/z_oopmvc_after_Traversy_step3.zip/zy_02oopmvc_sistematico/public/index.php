<?php
/**
* Step 2 after TraversyMVC PHP framework
* Step 1 is oop-php-mvc on Apr 25, 2019
*    https://github.com/sistematico/oop-php-mvc
*    Based on TraversyMVC : https://www.udemy.com/object-oriented-php-mvc
*/
  require_once('../app/bootstrap.php');

  // Init Core Library
  $init = new Router($pp1);
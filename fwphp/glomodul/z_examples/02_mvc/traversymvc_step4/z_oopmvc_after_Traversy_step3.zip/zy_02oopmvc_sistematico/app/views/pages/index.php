<?php
//J:\xampp\htdocs\zy_oopmvc_udemy\app\views\pages\index.php

// not J:\xampp\htdocs/views/inc/header.php
// yes J:\xampp\htdocs\zy_oopmvc_udemy\app\views\inc\header.php
require $pp1->module_app_path . '/views/inc/header.php'; ?>

  <div class="jumbotron jumbotron-fluid">
    <div class="container">

      <h1 class="display-3"><?php echo $data['title']; ?></h1>

      <p class="lead"><?php echo $data['description']; ?></p>

    </div>
  </div>

<?php
$file = __FILE__ ; // = call_from_path

require $pp1->module_app_path . '/views/inc/footer.php';

echo '<br /><br /><hr />'; include_once($pp1->wsroot_path .'/zinc/showsource.php');

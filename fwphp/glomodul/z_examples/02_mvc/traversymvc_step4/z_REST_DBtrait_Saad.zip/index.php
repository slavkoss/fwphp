<?php
  
  /**
   * J:\xampp\htdocs\zy_01fw_mvc\zy_REST_Saad\index.php
   * Application Main Page That Will Serve All Requests (module single entry point)
   */
defined( 'DBG' ) ?:  define( 'DBG', '1' );
              if (DBG) { ?>
              <h2>Home page code flow - CRUD code skeleton and pseudo code (comments)</h2>
              Ahmed Saad 
              <span><b>~~~~~Step 01: </b></span> <?=__FILE__?>, lin=<?=__LINE__?>
              <ol>
              <li><u>To see this code flow comment in App\Library\View::__construct : <b>//$this->render();</b> (or comment all lines).</u>
              <li>Statements : require_ once initializing.php and new \App\Library\Request()
              </ol>
              <?php }

  require_once( 'App/Library/initializing.php' );

  new \App\Library\Request('ROOT/'.basename(__FILE__));






/**
 * BASED ON @package Simple Framework @version 2.0.0 
 *    https://github.com/ahmad-sa3d/Simple-MVC-Framework
 *    @author Ahmed Saad <a7mad.sa3d.2014@gmail.com>
 *    @license https://creativecommons.org/licenses/by-sa/4.0/legalcode.txt CC-BY-SA-4.0
 *             Creative Commons Attribution Share Alike 4.0
 * AND ON B12phpfw @author Slavko Srako�i� Zagreb
 *   https://github.com/slavkoss/fwphp
 * FW Automatically Inject M For C method. FW Will search for M samenamed as C.
*/
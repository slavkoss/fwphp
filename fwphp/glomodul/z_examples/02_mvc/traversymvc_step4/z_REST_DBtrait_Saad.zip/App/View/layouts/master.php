<!DOCTYPE html>
<html>
<head>
  <!--J:\xampp\htdocs\zy_01fw_mvc\zy_REST_Saad\App\View\layouts\master.php-->

  <!--<title>@yield('title')</title>-->
  <title><?=$title?></title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="/zinc/themes/bootstrap/css/bootstrap.min.css">

  <!--{!! $this->url->htmlLink( 'bootstrap.min.css') !!}
  {!! $this->url->htmlLink( 'bootstrap-theme.min.css') !!}
  {!! $this->url->htmlLink( 'main.css') !!}

  {!! $this->url->htmlScript( 'jquery-213.min.js' ) !!}
  {!! $this->url->htmlScript( 'bootstrap.min.js' ) !!} -->
  
  <script>
    var baseUrl = '{{ $this->url->to('/') }}';
  </script>
</head>


<body>
  <!--@include( 'includes.nav' )-->
  <?php
    include_once(ROOT . '/App/View/includes/nav.php');
    //include_once('J:\xampp\htdocs\zy_01fw_mvc\zy_REST_Saad\App\View\includes\nav.php');
  ?>

  <!--@include( 'admin.includes.notification' )-->

  <div class="container">
    <!--@yield( 'content' )-->
    <?=$content?>
  </div>

  <!--@include( 'admin.includes.footer' )-->

  <!-- Foot Scripts -->
  <!--@yield( 'scripts' )-->


  <script type="text/javascript" src="<?=$wsroot_url?>zinc/themes/bootstrap/js/jquery.min.js"></script>
  <script src="<?=$wsroot_url?>zinc/themes/bootstrap/js/popper.min.js"></script>
  <script type="text/javascript" src="<?=$wsroot_url?>zinc/themes/bootstrap/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="<?=$wsroot_url?>zinc/util.js"></script>

  <script>
    //$('#year').text(new Date().getFullYear());
  </script>



</body>
</html>


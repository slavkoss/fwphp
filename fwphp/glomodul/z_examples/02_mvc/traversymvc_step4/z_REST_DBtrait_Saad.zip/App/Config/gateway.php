<?php
/**
 * G ateway Configuration is to configure Application Access For Specific Uris.
 */

use App\Library\Redirect;

return [
  'admin' => function(){
    if( !$this->session->isLoggedIn() )
      return Redirect::to( '/auth/login' );

    return ( $this->session->user->admin );
  },

  'auth/login' => function(){
    return 1;
  },

];
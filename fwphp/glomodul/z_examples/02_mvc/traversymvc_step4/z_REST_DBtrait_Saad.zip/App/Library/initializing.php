<?php
/**
 * J:\xampp\htdocs\zy_01fw_mvc\zy_REST_Saad\App\Library\initializing.php
 * App Initializing File - BOOTSTRAPING AND CONFIG
 */

//J:\xampp\htdocs\zy_01fw_mvc\zy_REST_Saad :
defined( 'ROOT' ) ?:  define( 'ROOT', dirname( dirname(__DIR__) ) );

      if (DBG) { ?>
      <span style="font-size:1.2em;"><b>~~~~~Step 02: ROOT<?=str_replace(ROOT,'',__FILE__)?></b></span> lin=<?=__LINE__?> required in index.php - BOOTSTRAPING AND CONFIG

      <ol>
      <li>02.1 Adressess (Win. oper. sys. paths) are constants. <span style="background:yellow;"><b>BETTER IS</b> $pp1</span> shared for all sites (which is <b>$page_ee_module_Property_Palette_array_object</b>). $pp1 is dependency injected in cls-es where needed, so we can change and add elements !! For each module (page) in own folder <span style="background:yellow;"><b>all scripts except shared are in ROOT and folders below ROOT are not needed</b></span> !!
      <span style="font-size:1.2em;">
          <ol>
          <li>ROOT=<?=ROOT?>
          <li>APP=ROOT.DS.'App'
          <li>LIB=APP.DS.'Library'
          <li>CONT=APP.DS.'Controllers'
          <li>MODEL=APP.DS.'Model'
          <li>VIEW=APP.DS.'View'
          <li>CONF=APP.DS.'Config'
          <li>ASSETS=ROOT.DS.'assets' 
          </ol>
      </span>

      <li>02.2 DB Constants
      <br />Require script which "return(array_conn_params)" : $database = require( CONF . DS . 'database.php' );
      
      
      <li>02.3 Register Autoloader (which requires any class script) - <span style="background:yellow;"><b>TO SIMPLE</b> </span><br />&nbsp;

      <li>02.4 CALL : <b>App\Library\DatabaseObjectTrait::openConnection(basename(__FILE__));</b> where (__FILE__ is caller) 

      <li>02.5 CALL Start Session : new App\Library\Session(basename(__FILE__));
      </ol>
      <?php
      }

// 1. Adress Constants :
defined( 'DS' ) ?:    define( 'DS', DIRECTORY_SEPARATOR );
defined( 'APP' ) ?:   define( 'APP', ROOT.DS.'App' );
defined( 'LIB' ) ?:   define( 'LIB', APP.DS.'Library' );
defined( 'CONT' ) ?:  define( 'CONT', APP.DS.'Controllers' );
defined( 'MODEL' ) ?: define( 'MODEL', APP.DS.'Model' );
defined( 'VIEW' ) ?:  define( 'VIEW', APP.DS.'View' );
defined( 'CONF' ) ?:  define( 'CONF', APP.DS.'Config' );
defined( 'ASSETS' ) ?:define( 'ASSETS', ROOT.DS.'assets' );

// 2. DB Constants :
$database = require( CONF . DS . 'database.php' );
defined( 'DB_HOSTNAME' ) ?:  define( 'DB_HOSTNAME', $database['db_hostname'] );
defined( 'DB_NAME' ) ?:  define( 'DB_NAME', $database['db_name'] );
defined( 'DB_USERNAME' ) ?:  define( 'DB_USERNAME', $database['db_username'] );
defined( 'DB_USERPWD' ) ?:  define( 'DB_USERPWD', $database['db_password'] );

// 3. Register Autoloader
function laoderFunc( $namespaced_class_name ){
                        // echo '<br />' . $namespaced_class_name . '<br />';
  $parts = explode( '\\', $namespaced_class_name );
  
  array_walk( $parts, function( $v ){
    return ucfirst( $v );
  } );
  
  // Passing glue string after array is deprecated. Swap the parameters
  //$path = ROOT . DS . join( $parts, DS ) . '.php';
  $path = ROOT . DS . join( DS, $parts ) . '.php';

  if( file_exists( $path ) )
    require( $path );
};

spl_autoload_register( 'laoderFunc' );

// 4. Open DB Connection
App\Library\DatabaseObjectTrait::openConnection(basename(__FILE__));

// 5. Start Session
new App\Library\Session(basename(__FILE__));


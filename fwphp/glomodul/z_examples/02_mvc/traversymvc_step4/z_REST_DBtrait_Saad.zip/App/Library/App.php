<?php
/**
 * App
 *
 * Application Service Container
 *
 * @package Simple Framework
 * @author  Ahmed Saad <a7mad.sa3d.2014@gmail.com>
 * @license https://creativecommons.org/licenses/by-sa/4.0/legalcode.txt CC-BY-SA-4.0 Creative Commons Attribution Share Alike 4.0
 */

namespace App\Library;

class App {
  
  /**
   * Array Holds Application Instances
   * @var array
   */
  protected static $instances = [];

  /**
   * Register An Application Instance
   * @param  String $key      Instance Name
   * @param  Object $instance Instance
   * @return Null
   */
  public static function register( string $key, $instance, string $called_from = '**UNKNOWN CALLER**' )
  {
      if (DBG) {
      echo '<br /><br /><span style="color:brown;"><b>~~~~~Step 03.01: '.__METHOD__ .' $key='.$key .'</b></span>' ;
      echo ' <b>Called from</b> '.$called_from ;
      
      echo '<br />'.__FILE__ .' lin='.__LINE__ ;

      echo '<br />(CLS_OBJECT_)VARIABLE->MODULE_LEVEL_GLOBAL_ARRAY so: self::$instances[$key]=$instance;' ;
      }

    if( !isset( self::$instances[ $key ] ) )
    {
      // Register
      self::$instances[ $key ] = $instance;
    }
  }

  /**
   * Get An Registerd Instance
   * @param  String $key Instance Name
   * @return Mixed      Object If Found Otherwise Null
   */
  public static function get( string $key, string $called_from = '**UNKNOWN CALLER**' )
  {
      if (DBG) { ?>
      <br /><i><span style="color:brown;">~~~~~Step 03.02: <?=__METHOD__?> $key=<?=$key?>' (calls has)</span></i><?=__FILE__?> lin=<?=__LINE__?>

      <br /><b>Called from</b> <?=$called_from?>, return isset( self::$instances[ $key ] );
      <?php }


    return self::has( $key, __METHOD__ ) ? self::$instances[ $key ] : null;
  }

  
  /**
   * Check If An Instance Registered
   * @param  String  $key Instance name
   * @return boolean
   */
  public static function has( string $key, string $called_from = '**UNKNOWN CALLER**' )
  {
      if (DBG) { ?>
      <br /><i><span style="color:brown;">~~~~~Step 03.03: <?=__METHOD__?> $key=<?=$key?>'</span></i><?=__FILE__?> lin=<?=__LINE__?>

      <br /><b>Called from</b> <?=$called_from?>, return isset( self::$instances[ $key ] );
      <?php }

    return isset( self::$instances[ $key ] );
  }
  
}
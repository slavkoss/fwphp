<?php
/**
 * App G ateway
 *
 * Application Guard, As Middleware To Check Application Urls Access Conditions
 *
 *
 * @property-read bool $passes If Condition Satisfies Request
 * @property-read Object $request App Request Instance
 * @property-read Object $session App Session Instance
 * @property-read Array $config App Defined Access Configurations
 */

namespace App\Library;

use App\Library\Request;
use App\Library\App;
use App\Library\Redirect;
use App\Library\MagicGetterTrait;


class Gateway{

  use MagicGetterTrait;

  /**
   * Represents Satisfaction Status
   * @var boolean
   */
  protected $passes = true;

  /**
   * App Request Instance
   * @var Object
   */
  protected $request;

  /**
   * Application Session Instance
   * @var Object
   */
  protected $session;

  /**
   * Application Defined Access Configuration
   * @var Array
   */
  protected $config;
  
  
  /**
   * Constructor
   * @param Request $request Application Request Instance
   */
  public function __construct( Request $request, string $called_from = '**UNKNOWN CALLER**' )
  {
          if (DBG) { ?> <h3><i><span style="color:gray;">~~~~~Step 06: <?=__METHOD__?></h3>
          <?=__FILE__?> lin=<?=__LINE__?>
          <br />$called_from=<?=$called_from?> </span></i>, return $this->check();
          <?php }

    $this->request = $request;
    $this->session = App::get( 'session', __METHOD__ );
    App::register( 'gateway', $this, __METHOD__ );

    $this->config = include CONF . DS . 'gateway.php';
    
    return $this->check();
  }

  /**
   * Check Defined Request Conditions
   * @return boolean If Passess Or Fails
   */
  protected function check()
  {
    foreach( $this->config as $uri => $closure )
    {
      if( $this->request->match( $uri ) )
      {
        if( !call_user_func( $closure ) )
        {
          $this->passes = false;
          break;
        }
      }
    }

    return $this->passes;
  }
}
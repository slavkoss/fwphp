<?php
/**
 * Base Controller
 *
 * @property-read App\Library\Session $session Session Application session Instance
 * 
 */

namespace App\Controllers;

use App\Library\App;
use App\Library\MagicGetterTrait;

class Controller
{
  use MagicGetterTrait;

  /**
   * Application session instance
   * @var App\Library\Session
   */
  protected $session;
  
  
  /**
   * Constructor
   */
  public function __construct(string $called_from = '**UNKNOWN CALLER**')
  {
          if (DBG) { ?> <h3><i><span style="color:gray;">~~~~~Step 07: <?=__METHOD__?></h3>
          <?=__FILE__?> lin=<?=__LINE__?>
          <br />$called_from=<?=$called_from?> </span></i>, $this->session = App::get( 'session', __METHOD__ );
          <?php }

    // Register
    App::register( 'controller', $this, __METHOD__ );

    $this->session = App::get( 'session', __METHOD__ );
  }

  /**
   * Make Session notification
   * @param  String $type    Notification Type: success, danger, warning
   * @param  String $message Notification Message
   * @param  String $link    Notification Provided Link
   */
  public function makeNotification( $type, $message, $link = null )
  {
    $this->session->set( 'notification', compact( 'type', 'message', 'link' ) );
  }

  
  /**
   * Make Session Succress notification
   * @param  String $message Notification Message
   * @param  String $link    Notification Provided Link
   */
  public function makeSuccessNotification( $message, $link = null )
  {
    $type = 'success';
    $this->session->set( 'notification', compact( 'type', 'message', 'link' ) );
  }

  
  /**
   * Make Session Error notification
   * @param  String $message Notification Message
   * @param  String $link    Notification Provided Link
   */
  public function makeErrorNotification( $message, $link = null )
  {
    $type = 'danger';
    $this->session->set( 'notification', compact( 'type', 'message', 'link' ) );
  }

  /**
   * Hash Password
   * @param  String|Integer $value Password
   * @return String        Hashed Password
   */
  public function hashMake( $value )
  {
    return password_hash( $value, PASSWORD_DEFAULT );
  }

  /**
   * Verify Hashed Password
   * @param  String|Integer   $value  Password
   * @param  String       $hash   Hashed Password
   * @return Boolean              True If Verified, Otherwise false
   */
  public function hashVerify( $value, $hash )
  {
    return password_verify( $value, $hash );
  }

}

// الحمد لله
// Ahmed saad, 1 Oct 2016 12:15 AM
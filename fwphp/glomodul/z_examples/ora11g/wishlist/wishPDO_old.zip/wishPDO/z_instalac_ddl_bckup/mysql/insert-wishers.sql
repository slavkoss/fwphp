INSERT INTO wishers (name, password) VALUES ('Tom', 'tomcat');
INSERT INTO wishers (name, password) VALUES ('Jerry', 'jerrymouse');

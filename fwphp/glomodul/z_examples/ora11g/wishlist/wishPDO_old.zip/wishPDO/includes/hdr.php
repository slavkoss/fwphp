<!DOCTYPE html>
<html lang="hr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head tag -->
    
    <meta name="description" content="Own PHP framework - mmjoin messages">
    <meta name="author" content="Slavko Srako�i�, Zagreb, Croatia (see my blog at phporacle.altervista.org)">
    <meta name="licence" content=GPL2">
    
      <!--[if lt IE 9]>
      <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <![endif]-->
      
    <!-- Title, Custom css -->
    <title>Teme</title>
    <link href="includes/wishlist.css" type="text/css" rel="stylesheet" media="all" />
  </head>
  
   <body>


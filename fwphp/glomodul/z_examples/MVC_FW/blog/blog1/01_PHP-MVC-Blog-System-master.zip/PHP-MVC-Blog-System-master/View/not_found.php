<?php
/**
 * @author           Pierre-Henry Soria <phy@hizup.uk>
 * @copyright        (c) 2015-2017, Pierre-Henry Soria. All Rights Reserved.
 * @license          Lesser General Public License <http://www.gnu.org/copyleft/lesser.html>
 * @link             http://hizup.uk
 */
?>
<?php require 'inc/header.php' ?>

<h1>Page Not Found</h1>

<p>Whoops! Sorry but this page doesn't seem to exist.</p>

<?php require 'inc/footer.php' ?>

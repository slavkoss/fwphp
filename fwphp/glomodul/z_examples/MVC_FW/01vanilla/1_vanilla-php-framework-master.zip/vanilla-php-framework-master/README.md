## Introduction
A very simple & lightweight raw PHP framework that focuses mainly the developers, who want to speed up their development process. It is developed with MVC structure and does not use any external packages.

## Requirements
- Composer is required. Get composer from here: https://getcomposer.org/download/

## Installation
- Clone the repository,
- Run this command in the project directory: 
```composer dump-autoload```
- Change your configuration in ```app/config.php``` file

### Enjoy!

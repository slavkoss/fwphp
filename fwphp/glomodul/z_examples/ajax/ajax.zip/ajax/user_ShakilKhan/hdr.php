<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1 shrink-to-fit=no">
  <title>B12phpfw</title>
  
  <link rel="stylesheet" href="/zinc/themes/bootstrap/css/bootstrap.min.css">
  <!--link rel="stylesheet" href="assets/css/bootstrap.min.css"-->
  <!--link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css"-->
  <!--link rel="stylesheet" href="assets/css/style.css"-->
  <?php
  if (isset($css1)) echo '<link rel="stylesheet" href="'.$css1.'">';
  if (isset($css2)) echo '<link rel="stylesheet" href="'.$css2.'">';
  if (isset($css3)) echo '<link rel="stylesheet" href="'.$css3.'">';
  if (isset($css4)) echo '<link rel="stylesheet" href="'.$css4.'">';
  ?>
</head>
<body>
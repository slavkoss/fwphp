<script type="text/javascript" src="/zinc/themes/bootstrap/js/jquery.min.js"></script>
<script src="/zinc/themes/bootstrap/js/popper.min.js"></script>
<script type="text/javascript" src="/zinc/themes/bootstrap/js/bootstrap.min.js"></script>

<!--script type="text/javascript" src="assets/js/j query.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/p opper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
<script type="text/javascript" src="assets/js/b ootstrap.min.js"></script>
<script type="text/javascript" src="assets/js/s imple.js"></script>
<script type="text/javascript" src="assets/js/cre_ signup.js"></script>
<script type="text/javascript" src="assets/js/r ead_l ogin.js"></script-->

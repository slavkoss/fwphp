<?php
// J:\awww\www\fwphp\glomodul\z_examples\ajax\prettyman\ajaxdemo.php
echo '<h2>'. __FILE__ . ' SAYS Hello' .'</h2>';
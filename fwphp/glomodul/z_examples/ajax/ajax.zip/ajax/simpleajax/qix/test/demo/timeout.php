<?php
for ($x = 0; $x < 1000; $x++) {
	sleep(1);
}

echo 'done';
?>
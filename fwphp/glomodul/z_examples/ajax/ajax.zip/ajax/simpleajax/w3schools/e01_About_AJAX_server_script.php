<h2>AJAX (Asynchronous JavaScript And XML)</h2>
<a href="https://www.w3schools.com/js/js_ajax_intro.asp">AJAX on w3schools</a>

<p><strong>F5 to close this text.</strong>

<p><?=basename(__FILE__) .' (may be .txt but than this line is not displayed) SAYS :  <br /><strong>$_GET[\'param1\']='. $_GET['param1']?></strong>

<p><strong><?='$_POST[\'post_data1\']='. $_POST['post_data1']?></strong>

<p>AJAX is a misleading name. AJAX applications might use XML to transport data, but it is equally common to transport data as plain text or JSON text.

<p>AJAX is not a programming language but technique for accessing web servers from a web page. 
AJAX allows web pages to be updated asynchronously by exchanging data with a web server behind the scenes. This means that it is possible to update parts of a web page, without reloading the whole page.

<p>AJAX is developer's dream, because you can:
<ol>
<li>Read data from a web server - after the page has loaded
<li>Update a web page without reloading the page
<li>Send data to a web server - in the background
</ol>
<?php

echo 'Rows filter string search_string_value ='.$_POST['search_string']
     .",\nparam2_value =".$_POST['param2']
;

?>
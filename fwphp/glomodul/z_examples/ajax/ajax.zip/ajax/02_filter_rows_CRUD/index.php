<?php
//      J:\awww\www\fwphp\glomodul4\help_sw\test\AJAX\01_cars_diaz\index.php
// http://dev1:8083/fwphp/glomodul4/help_sw/test/AJAX/01_cars_diaz/

// https://github.com/slavkoss/fwphp/tree/master/fwphp/glomodul4/help_sw/test/AJAX/01_cars_diaz
// http://phporacle.altervista.org/13-jquery-php-bootstrap-ajax-db-table-rows-crud/

//       jQuery, PHP, Bootstrap : AJAX DB table rows CRUD

// TO COMPLICATED, SEE 0302pdo_search_moj_rep_filter_named_params.php !!!!!!!

require 'tbl1_view.php' ;
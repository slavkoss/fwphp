<?php
// J:\awww\www\fwphp\glomodul4\help_sw\test\AJAX\01_cars_diaz\db.php
//ob_start(); //so we can do redirection eg header("Location: index.php");

//$connection = mysqli_connect('localhost', 'root', '','ajax');
$connection = mysqli_connect('localhost', 'root', '','tema');


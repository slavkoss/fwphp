<?php
    phpinfo();
?>

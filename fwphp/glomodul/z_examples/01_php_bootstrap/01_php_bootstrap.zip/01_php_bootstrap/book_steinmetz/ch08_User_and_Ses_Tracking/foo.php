<?php
print "\.";
?>

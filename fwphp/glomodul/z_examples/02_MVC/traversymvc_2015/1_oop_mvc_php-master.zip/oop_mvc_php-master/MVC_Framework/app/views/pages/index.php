<?php require APPROOT . "/views/includes/header.php"; ?>
    <h1><?php echo $data['title']; ?></h1>
    <p>This is the Traversy MVC PHP framework. Please refer to the docs on how to use it.</p>
<?php require APPROOT . "/views/includes/footer.php"; ?>
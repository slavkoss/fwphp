<?php require APPROOT . "/views/includes/header.php"; ?>

<h1><?php echo $data['title']; ?>

<?php require APPROOT . "/views/includes/footer.php"; ?>
<?php
// J:\awww\www\fwphp\glomodul4\mkd\Help.php

//
namespace B12phpfw ; //B12phpfw\fwphp\glomodul4\mkd

class Help extends Home //higher mnucls in tree
{

    // class attributes
    //R O U T I N G  T A B L E  level 2 (pages properties) - links, see H ome cls crelink($ruta)

    //class operations - methods
    public function Display()
    {
      ?>
    <h1>Help</h1>
    
    <h2>&nbsp;Mkd Links</h2>
<a href="http://dev1:8083/fwphp/glomodul4/mkd/?Home/edit/J:/awww/www/readme.md" target="_blank">&nbsp;http://dev1:8083/fwphp/glomodul4/mkd/?Home/edit/J:/awww/www/readme.md</a><br>
<br>
<a href="http://dev1:8083/fwphp/glomodul4/mkd/?Home/md2htm/J:/awww/www/readme.md" target="_blank">http://dev1:8083/fwphp/glomodul4/mkd/?Home/md2htm/J:/awww/www/readme.md</a>
<br /><br><br />
<a href="http://dev1:8083/fwphp/glomodul4/mkd/?Home/edit/001_MDcheatsheet.txt" target="_blank">http://dev1:8083/fwphp/glomodul4/mkd/?Home/edit/001_MDcheatsheet.txt</a><br>
<br>
<a href="http://dev1:8083/fwphp/glomodul4/mkd/?Home/md2htm/001_MDcheatsheet.txt" target="_blank">http://dev1:8083/fwphp/glomodul4/mkd/?Home/md2htm/001_MDcheatsheet.txt</a>
<br /><br />
<br>
<a href="http://dev1:8083/fwphp/glomodul4/mkd/?Home/edit/01/00______%20MKD%20FIRST%20DOC%20GROUP%20______.txt">http://dev1:8083/fwphp/glomodul4/mkd/?Home/edit/01/00______%20MKD%20FIRST%20DOC%20GROUP%20______.txt</a>
<br><br>
<a href="http://dev1:8083/fwphp/glomodul4/mkd/?Home/md2htm/01/00______%20MKD%20FIRST%20DOC%20GROUP%20______.txt" target="_blank">http://dev1:8083/fwphp/glomodul4/mkd/?Home/md2htm/01/00______%20MKD%20FIRST%20DOC%20GROUP%20______.txt</a>&nbsp;
    
    <?php
    } //e n d  f n  D i s p l a y()


} //e n d  c l s
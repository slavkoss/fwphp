<?php
//  This is fourth of 5 home page parts (all are prefixed with "h_")
$tmp     = $img_url . 'ic_done_white_32dp.png' ;
$img_url_done_link_white = '<img src="'.$tmp.'" alt="'.$tmp.'" title="'.$tmp.'">';
?>

  <article">
    <div id="create2" class="container"><a href="#lcs">TOP</a>
      <h1 class="section-heading">2. Explain - Create</h1>
      <p>Write code or text about something. <a href="#">More</a></p>


      <div>

          <img class="u-max-full-width" src="/vendor/b12phpfw/img//mvc_M_V_and_M_C_V_data_flow.jpg">
          <br><br>
          <img class="u-max-full-width" src="/vendor/b12phpfw/img/mvc_M_C_V.jpg">


          <br><br>
          <h3>2.1 Create your passion (Msg share, ACXE2, Mini3 PDO, kalendar...)</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus provident... </p>
          
            <div>
              <?=$img_url_done_link_white?>ccccccc cccccccc
            </div>


            <div>
              <?=$img_url_done_link_white?>Todo / Done
            </div>
          
        <div>
          <img src="<?=$img_url?>edit.png" alt="" class="img-fluid mb-3 rounded-circle"> &nbsp; ddddd ddddddd
        </div>

            <br />This view (report) is included script <?=__FILE__?>
               where h_... means part of  h o m e  page. <?=basename(__FILE__)?> is included in home.php.
               It is typical static web page.


      </div>
  </article>

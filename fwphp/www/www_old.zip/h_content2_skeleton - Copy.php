<?php
//  This is fourth of 5 home page parts (all are prefixed with "h_")
$tmp     = $img_url . 'ic_done_white_32dp.png' ;
$img_url_done_link_white = '<img src="'.$tmp.'" alt="'.$tmp.'" title="'.$tmp.'">';
?>

  <div class="section categories">
    <div class="container">
      <h3 class="section-heading">2. Explain - Create</h3>
      <p class="section-description">Write code or text about something.</p>
      <a class="button button-primary" href="#">More</a>


      <div class="row">
        <div class="one-half column category">
          <img class="u-max-full-width" src="/vendor/b12phpfw/img//mvc_M_V_and_M_C_V_data_flow.jpg">
        </div>
        <div class="one-half column category">
          <img class="u-max-full-width" src="/vendor/b12phpfw/img/mvc_M_C_V.jpg">
        </div>
      </div>


          <h3>2.1 Create your passion (Msg share, ACXE2, Mini3 PDO, kalendar...)</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus provident... </p>
          
            <div>
              <?=$img_url_done_link_white?>ccccccc cccccccc
            </div>


            <div>
              <?=$img_url_done_link_white?>Todo / Done
            </div>
          
        <div>
          <img src="<?=$img_url?>edit.png" alt="" class="img-fluid mb-3 rounded-circle"> &nbsp; ddddd ddddddd
        </div>

            <br />This view (report) is included script <?=__FILE__?>
               where h_... means part of  h o m e  page. <?=basename(__FILE__)?> is included in home.php.
               It is typical static web page.


    </div>
  </div>
